# Customer Churn ML Project

Professional ML project for predicting customer churn.
