# Helper functions
